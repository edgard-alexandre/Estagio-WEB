<!DOCTYPE html>
<html lang="pt-br">
    <head>
	   <meta charset="UTF-8">
	   <title>Física Antunes</title>
        <link href="http://localhost/FisicaAntunes02/assets/bootstrap/css/bootstrap.min.css" rel="stylesheet">
        <script src="http://localhost/FisicaAntunes02/assets/jquery-3.2.0.min.js"  type="text/javascript"></script>
        <script src="http://localhost/FisicaAntunes02/assets/bootstrap/js/bootstrap.min.js"  type="text/javascript"></script>
		<link href="http://localhost/FisicaAntunes02/assets/css/estilosHome.css" rel="stylesheet">
    </head>
    <body>
    <div id="eletronfoto">
    </div id="Meenu">
        <nav id="menunav">
            <ul id="menu" class="nav nav-tabs">
                <li>
                    <form action="http://localhost/FisicaAntunes02/home"><button id="menuu" type="submit" class="btn btn-default navbar-btn"><b>Home</b></button></form>
                 </li>
                                
                    <li>
                     <a class="dropdown-toggle" data-toggle="dropdown" href="#" role="button" aria-haspopup="true" aria-expanded="false" id="menuu">Graduação<span class="caret"></span></a>
                    <ul id="menuuu" class="dropdown-menu">
                      <!---  <?php 
							foreach($disciplinas as $disciplina){
                        ?>
                         <li>
                         <?php
                            $infos = array('id'=>'botaodis');
                          echo form_open(base_url("home/disciplina")) .
                               form_submit('nomeplina',$disciplina->nome,$infos).
                               form_close();
                        ?>
                         
                           
                           <!---
                              <?php echo anchor(base_url("home/disciplina"),$disciplina->nome);
                                    echo form_input('campo_plina',$disciplina->nome); 
                                
                              ?>
                           
                          </li>
                        <?php
                          }
                        ?>-->
                          <?php 
							foreach($disciplinas as $disciplina){
                        ?>
                        <li>
                           <?php echo anchor(base_url("home/disciplina/".$disciplina->nome),$disciplina->nome);
                           ?> 
                        </li>
                          <?php
                          }
                        ?>
                     </ul> 
                    </li>

                    <li>
                     <a class="dropdown-toggle" data-toggle="dropdown" href="#" role="button" aria-haspopup="true" aria-expanded="false" id="menuu">Turmas<span class="caret"></span></a>
                     <ul id="menuuu" class="dropdown-menu">
                          <?php 
							foreach($disciplinas as $disciplina){
                        ?>
                         
                        <li id="teste">
                          
                           <?php echo anchor(base_url("home/disciplina/".$disciplina->nome),$disciplina->nome);
                           ?> 
                          
                        </li>
                       
                          <?php
                          }
                        ?>
                     </ul> 
                    </li>

                    <li>
                        <form action="http://localhost/FisicaAntunes02/home/teste">
                        <button id="menuu" type="submit" class="btn btn-default navbar-btn"><b>Teste</b></button>
                        </form>     
                    </li>


                    <li>   
                        <button type="button" class="btn btn-default navbar-btn" id="menuu" data-toggle="modal" data-target="#exampleModal"><b>Contato</b></button> 
                    </li> 



                    <li>
                        <button type="button" class="btn btn-default navbar-btn" id="menuu" data-toggle="modal" data-target="#exampleModal02"><b>Login</b></button>
                    </li>
                
            </ul>  
        </nav>


        <div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel">
            <div class="modal-dialog" role="document">
                <div class="modal-content">
                    <div class="modal-body">
          
             Telefones(CEFET - Formação Geral): (35) 3690-4216  <br>
                                                (35) 3690-4214  <br>
                                                (35) 3690-4234  <br>
             Email: pedroantunes.pd@gmail.com <br>
                    antunes.pd@gmail.com
        
                    </div>
                </div>
            </div>
        </div>

        <div class="modal fade" id="exampleModal02" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel">
            <div class="modal-dialog" role="document">
                <div class="modal-content">
                    <div class="modal-header">
                        <h4 class="modal-title" id="exampleModalLabel02">Para permissões administrativas, insira sua senha:</h4>
                    </div>
                    <div class="modal-body">
                        <div class="form-group">
                            <?php
                                $infoss = array('class' => 'form-label');
          		                $info = array('class' => 'form-control');
          		                $infos = array('class' => 'btn btn-default dropdown-toggle','id' => 'botao');
	      		                   echo form_open(base_url("home/login")) .
          		                    form_label("Senha: " ,"txt_senha",$infoss).br() .
                                       form_input("txt_camposenha",'',$info) . br().
                                       form_submit('nomequalquer','Enviar Mensagem',$infos).
                                       form_close();
                            ?>
                        </div>
                    </div>  
                </div>
            </div>
        </div>
<!--
<div id="infosPedro">

<img src="http://localhost/FisicaAntunes02/assets/images/fotoPedro.jpg">
<div id="conteudo">
   Professor do Quadro Efetivo no Centro Federal de Educação Tecnológica de Minas Gerais - CEFET/MG Varginha, Graduado em Física pela UNIFOR/MG, Mestre em Ciências - Materiais para Engenharia pela Universidade Federal de Itajubá - UNIFEI, atualmente é aluno de doutorado do Programa Petrobras de Formação de Recursos Humanos - PFRH no Instituto de Engenharia Mecânica da UNIFEI e Tesoureiro do UNIFEI Student Chapter da SPE - Society of Petroleum Engineers, atua em áreas relacionadas à Ensino de Física, Energia, Petróleo e Materiais para Engenharia. Dedica-se a estudar a influência dos processos de soldagem na microestrutura, nas propriedades mecânicas, de corrosão e de desgaste em materiais de engenharia voltados para a indústria de petróleo através do uso de técnicas experimentais.
</div>
</div>

-->
    </body>
</html>

