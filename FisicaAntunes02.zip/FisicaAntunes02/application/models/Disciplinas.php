<?php defined('BASEPATH') OR exit('No direct script access allowed');
class Disciplinas extends CI_Model {
        function __construct() {
           parent::__construct();
          
        }
     public function vraw($idArquivo){
       $conteudo['arquivo'] = $this->db->get_where('arquivos',array('idArquivo='=>$idArquivo))->result();
       foreach($conteudo['arquivo'] as $arquivo){
           $idDisciplina = $arquivo->idDisciplina;
           $nomeArquivo = $arquivo->nomeArquivo;
       } 
       $this->db->where('nomeArquivo',$nomeArquivo);
      $this->db->where('idDisciplina',$idDisciplina);
        if($this->db->delete('arquivos')){
            $caminho_para_arquivo = './uploads/disciplinas/'.$idDisciplina.'/'.$nomeArquivo;
            if(file_exists($caminho_para_arquivo)){
                if(unlink($caminho_para_arquivo)){
                   redirect('adm');
                }
            }      
        }else{
          echo 'deu ruim';
        } 
     }
      public function listarDisciplinas(){
         return $this->db->get('disciplinas')->result(); 
      }
       public function arquivosDisciplina(){
         return $this->db->get('arquivos')->result(); 
      }
      public function cadastrarDisciplina($nomeDisciplina){
         $dados = array(
     	    'nome' => $nomeDisciplina,
     	   );
         $this->db->insert('disciplinas',$dados);
      }
     
    public function verificaUpload($arquivoUpload,$idDisciplina){
     $var=FALSE;
     $conteudo['arquivo'] = $this->db->get_where('arquivos',array('nomeArquivo='=>$arquivoUpload,'idDisciplina='=>$idDisciplina))->result();
       if($conteudo['arquivo'] != null){
           $var = TRUE;
       }  
        return $var;
     }

  public function obterIdArquivo($arquivoUpload,$idDisciplina){
       $conteudo['arquivo'] = $this->db->get_where('arquivos',array('nomeArquivo='=>$arquivoUpload,'idDisciplina='=>$idDisciplina))->result();
       foreach($conteudo['arquivo'] as $arquivo){
           $idArquivo = $arquivo->idArquivo;
       }
        return $idArquivo;
    }

 public function renomear($id,$arqExc){
			$data = array(
        		'nomeArquivo' => $arqExc,
			);
        $this->db->where('idArquivo',$id);
        $this->db->update('arquivos',$data);
    }

   public function deletarRenomeado($idDisciplina,$arqExc){
      $this->db->where('nomeArquivo',$arqExc);
        if($this->db->delete('arquivos')){
            $caminho_para_arquivo = './uploads/disciplinas/'.$idDisciplina.'/'.$arqExc;
            if(file_exists($caminho_para_arquivo)){
                unlink($caminho_para_arquivo);           
            }      
        }else{
          echo 'deu ruim';
        } 
   }

public function nomeUpload($arquivoUpload,$idDisciplina){
     	  $dados = array(
     	     'nomeArquivo' => $arquivoUpload,
           'idDisciplina'=> $idDisciplina
     	  );
           $this->db->insert('arquivos',$dados);
           
       }
      public function deletarArquivoDisciplina($nomeArquivo,$idDisciplina){
      $this->db->where('nomeArquivo',$nomeArquivo);
      $this->db->where('idDisciplina',$idDisciplina);
        if($this->db->delete('arquivos')){
            $caminho_para_arquivo = './uploads/disciplinas/'.$idDisciplina.'/'.$nomeArquivo;
            if(file_exists($caminho_para_arquivo)){
                if(unlink($caminho_para_arquivo)){
                   redirect('adm');
                }
            }      
        }else{
          echo 'deu ruim';
        } 
   }

  public function arquivosPorDisciplina($nomeDisciplina){
        $conteudo['disciplina'] = $this->db->get_where('disciplinas', array('nome=' => $nomeDisciplina))->result();
          foreach($conteudo['disciplina'] as $disciplina){
            $idDisciplina = $disciplina->idDisciplina;
          }  
        
        return $this->db->get_where('arquivos', array('idDisciplina=' => $idDisciplina))->result();
        
     }
  
   
      public function obterIdDisciplina($nomeDisciplina){
        $conteudo['disciplina'] = $this->db->get_where('disciplinas', array('nome=' => $nomeDisciplina))->result();
          foreach($conteudo['disciplina'] as $disciplina){
            $idDisciplina = $disciplina->idDisciplina;
          }  
          return  $idDisciplina;
      }

      public function deletarDisciplina($idDisciplina){
         $conteudo['arquivosExclusao'] = $this->db->get_where('arquivos', array('idDisciplina=' => $idDisciplina))->result();
           foreach($conteudo['arquivosExclusao'] as $arquivoExclusao){
             $this->db->where('idDisciplina',$arquivoExclusao->idDisciplina);
               if($this->db->delete('arquivos')){
                 $caminho_para_arquivo = './uploads/disciplinas/'.$idDisciplina.'/'.$arquivoExclusao->nomeArquivo;
                   if(file_exists($caminho_para_arquivo)){
                      unlink($caminho_para_arquivo);
                   }      
               }
           }
         if(rmdir('../FisicaAntunes02/uploads/disciplinas/'.$idDisciplina)){
           $this->db->where('idDisciplina',$idDisciplina);
           $this->db->delete('disciplinas');
             redirect('adm');
         }else{
           echo "Algo deu errado no processo";
         }
      }

      public function renomearDisciplina($novoNome,$idDisciplina){
        $data = array(
          'nome' => $novoNome,
		  );
        $this->db->where('idDisciplina',$idDisciplina);
        $this->db->update('disciplinas',$data); 
        redirect('adm');
    }



}


