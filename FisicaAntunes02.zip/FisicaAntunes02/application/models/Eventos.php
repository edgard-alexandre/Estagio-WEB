<?php defined('BASEPATH') OR exit('No direct script access allowed');
class Eventos extends CI_Model {
        function __construct() {
           parent::__construct();
        }
        public function cadastrarEvento($nomeEvento,$conteudoEvento){
           $dados = array(
     	     'nomeEvento' => $nomeEvento,
           'conteudoEvento'=>$conteudoEvento,
     	  );
           $this->db->insert('eventos',$dados);
        }
       public function obterIdEvento($nomeEvento){
        $conteudo['evento'] = $this->db->get_where('eventos',array('nomeEvento='=>$nomeEvento))->result();
        foreach($conteudo['evento'] as $evento){
           $idEvento = $evento->idEvento;
        }
        return $idEvento;
       }
      public function listarEventos(){
         return $this->db->get('eventos')->result(); 
      }
      public function alterarEvento($idEvento,$conteudoEvento){
        $data = array(
          'conteudoEvento' => $conteudoEvento,
		  );
        $this->db->where('idEvento',$idEvento);
        $this->db->update('eventos',$data); 
        redirect('evento');
    }
     public function excluirEvento($idEvento){
        $this->db->where('idEvento',$idEvento);
        if($this->db->delete('eventos')){
          $caminho_para_arquivo = './uploads/eventos/'.$idEvento;
            if(file_exists($caminho_para_arquivo)){
                unlink($caminho_para_arquivo);           
            }      
          redirect('evento');
         }else{
          echo "Erro ao deletar evento ".$idEvento;
         }
     }
}
