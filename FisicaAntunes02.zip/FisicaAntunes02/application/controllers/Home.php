<?php   defined('BASEPATH') OR exit('No direct script access allowed');

class Home extends CI_Controller {
    function __construct() {
        parent::__construct();
        $this->load->helper('file');
        $this->load->helper('date');
        $this->load->helper('download');
        $this->load->helper('form');
        $this->load->helper('url');
        $this->load->library('upload');
        
    }

	public function index(){
        $this->load->model('Disciplinas','',TRUE); 
        $disciplinas['disciplinas'] = $this->Disciplinas->listarDisciplinas();
		$this->load->view('home',$disciplinas);	
 	
	}	

    public function login(){
        $this->load->model('Login','',TRUE); 
        $usuario = $this->input->post('txt_camposenha');
        $this->Login->verificacao($usuario);  
       
    }

    public function graduacao(){
     //verifica se o usuario logou.Views usadas sao inexistentes
      if(!$this->session->userdata('logado')){
          $this->load->view('Y');
      }else{
         $this->load->model('Graduacao','',TRUE);
         $this->load->model('Upload','',TRUE);
         $hor['resultado'] = $this->Graduacao->consultarHorarios();
         $comp['nomes'] = $this->Upload->consultarNomes();
         $comp['compromissos'] = $this->Graduacao->consultarCompromissos();
         $this->load->view('graduacao',$comp);
      }
    }

    public function teste(){
        $this->load->model('Upload','',TRUE);
        $data['resultado'] = $this->Upload->consultarNomes();
        $this->load->view('teste',$data);	
    }

    public function escrever(){
       $usuario = $this->input->post('txt_camposenha'); 
    }



	public function salvar(){  
               $this->load->model('Upload','',TRUE);
               
    		    $usuario = $_FILES['arquivo']['name']; 
    			$configuracao = array(
    		    'upload_path'   => './uploads/',
    		    'allowed_types' => 'jpg|png|gif|pdf|zip|rar|doc|xls|mp3',
    		    'max_size'      => '5000000',
                'max_width'     => '3000',
                'max_height'    => '2000',
                'remove_spaces' => 'TRUE',
    	);      
    			
    	    $this->upload->initialize($configuracao);
    	 if($this->upload->do_upload('arquivo')){
               $this->Upload->nomeUpload($usuario);
               echo 'Arquivo salvo com sucesso';
        	 
     	 }else{
       		 echo $this->upload->display_errors();
       	 }
   }


   public function download(){
       $y = $this->input->post('userfile');
        $arquivoPath = './uploads'."/".$y;
        $arquivoPath;
        // forçamos o download no browser 
        // passando como parâmetro o path original do arquivo
        force_download($arquivoPath,null);
   }

  public function deletar(){
    
    $excluir = $this->input->post('campo_excluir');
    $this->load->model('Upload','',TRUE);
    $this->Upload->deletar($excluir);
   
  }

  


  public function deletarComp(){
    $excluir = $this->input->post('campo_excluir');
    $this->load->model('Upload','',TRUE);
    $this->Upload->deletarComp($excluir);
  }

  public function disciplina($nomeDisciplina){
     $nomeDisciplina = urldecode($nomeDisciplina);
     $this->load->model('Disciplinas','',TRUE); 
     //$conteudo['conteudoDisciplina'] = $this->Disciplinas->conteudoDisciplina($nomeDisciplina);
     $conteudo['logo'] = mb_substr($nomeDisciplina,0,3);
     $conteudo['logo'] = strtolower($conteudo['logo']); 
	 if ($conteudo['logo'] == "lab"){
         $conteudo['logo'] = "laboratorio";
      } else {
         $conteudo['logo'] = "fisica";
      }
     //$conteudo['logo'] = $nomeDisciplina;
     $this->load->model('Disciplinas','',TRUE); 
     $conteudo['disciplinas'] = $this->Disciplinas->listarDisciplinas();
     $this->load->view('graduacaoGenerico',$conteudo);	
     //echo $conteudo['logo'];
     
  }
}
