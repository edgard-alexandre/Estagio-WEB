<?php defined('BASEPATH') OR exit('No direct script access allowed');

class Disciplina extends CI_Controller {
    function __construct() {
        parent::__construct();
        /*$this->load->helper('file');
        $this->load->helper('download');
        $this->load->helper('form');
        $this->load->helper('url');
        $this->load->library('upload');  
       $this->load->helper('string'); 
*/    
    }

  public function verificaDisciplina(){
     $this->load->model('Disciplinas','',TRUE); 
     $arquivoOriginal = $_FILES['arquivo']['name']; 
     $idDisciplina =  $this->input->post('campo_idDisciplina'); 
     $verifica = $this->Disciplinas->verificaUpload($arquivoOriginal,$idDisciplina); 
     if($verifica){
       $id = $this->Disciplinas->obterIdArquivo($arquivoOriginal,$idDisciplina);
       $arqExc = 'arquivoqueseraexcluido';
       $velhoCaminho= '../FisicaAntunes02/uploads/disciplinas/'.$idDisciplina.'/'.$arquivoOriginal;
       $novoCaminho= '../FisicaAntunes02/uploads/disciplinas/'.$idDisciplina.'/'.$arqExc;
       rename($velhoCaminho,$novoCaminho);
       $this->Disciplinas->renomear($id,$arqExc);
       $this->Disciplinas->deletarRenomeado($idDisciplina,$arqExc);
       $this->salvar($arquivoOriginal,$idDisciplina);
      }else{
         $this->salvar($arquivoOriginal,$idDisciplina); 
     }
     
  }

	public function salvar($arquivo,$idDisciplina){    
            $this->load->model('Disciplinas','',TRUE); 
    			$configuracao = array(
    		    'upload_path'   => './uploads/',
    		    'allowed_types' => 'jpg|png|docx|odt|gif|pdf|zip|rar|doc|xls|mp3',
    		    'max_size'      => '0',
             'max_width' =>  '9999999999',
             'max_height' => '9999999999',
             'remove_spaces' => 'TRUE',
    	      );     
            $path = './uploads/disciplinas/'.$idDisciplina.'/';
            $configuracao['upload_path'] = $path;
    	 $this->upload->initialize($configuracao);
    	 if($this->upload->do_upload('arquivo')){
         $procura = '..';
         $substituto = '__';
         $arquivo = str_replace($procura,$substituto,$arquivo);
          $this->Disciplinas->nomeUpload($arquivo,$idDisciplina);
           echo 'Arquivo salvo com sucesso';
        	 //redirect('adm');
     	 }else{
       	  echo $this->upload->display_errors();
       	 }  
   }


   public function renomearDisciplina(){
       $this->load->model('Disciplinas','',TRUE);  
       
       $idDisciplina = $this->input->post('campo_idDisciplina');
       $v = sha1(md5($idDisciplina));
       $novoNome = $this->input->post($v);
       $this->Disciplinas->renomearDisciplina($novoNome,$idDisciplina); 
       
   }


   public function download(){
     $nomeArquivo = $this->input->post('campo_nomeArquivo');
     $idDisciplina = $this->input->post('campo_idDisciplina');
     $arquivoPath = './uploads/disciplinas/'.$idDisciplina.'/'.$nomeArquivo;
    // forçamos o download no browser 
     // passando como parâmetro o path original do arquivo
     force_download($arquivoPath,null);    
   }


   public function deletarDisciplina(){
     $this->load->model('Disciplinas','',TRUE); 
     $idDisciplina = $this->input->post('campo_idDisciplina');
     $this->Disciplinas->deletarDisciplina($idDisciplina);
     
   }

  public function deletarArquivoDisciplina(){
    $this->load->model('Disciplinas','',TRUE);
    $nomeArquivo = $this->input->post('campo_nomeArquivo');
    $idDisciplina = $this->input->post('campo_idDisciplina');
    $this->Disciplinas->deletarArquivoDisciplina($nomeArquivo,$idDisciplina); 
  }

  


  public function cadastroDisciplina(){
    $this->load->model('Disciplinas','',TRUE);
    $nome = $this->input->post('nomeDisciplina');
    $nomeDisciplina = $nome;
    $this->Disciplinas->cadastrarDisciplina($nomeDisciplina);
    $idDisciplina = $this->Disciplinas->obterIdDisciplina($nomeDisciplina);
    mkdir('../FisicaAntunes02/uploads/disciplinas/'.$idDisciplina, 0777);
    redirect('adm');
  }
 
  public function vraw(){
    $this->load->model('Disciplinas','',TRUE);
    $idArquivo = $this->input->post('campo_idArquivo');
    $this->Disciplinas->vraw($idArquivo);
  }

  public function disciplina($nomeDisciplina){
     $nomeDisciplina = urldecode($nomeDisciplina);
     $this->load->model('Disciplinas','',TRUE); 
     $this->load->model('Tecnicos','',TRUE); 
     $conteudo['nomeDisciplina'] = $nomeDisciplina;
     $conteudo['arquivosDisciplina'] = $this->Disciplinas->arquivosPorDisciplina($nomeDisciplina);
     $conteudo['disciplinas'] = $this->Disciplinas->listarDisciplinas();
     $conteudo['tecnicos'] = $this->Tecnicos->listarTecnicos();
     $conteudo['logo'] = mb_substr($nomeDisciplina,0,3);
     $conteudo['logo'] = strtolower($conteudo['logo']);
 
	 if ($conteudo['logo'] == "lab"){
         $conteudo['logo'] = "laboratorio";
      } else {
         $conteudo['logo'] = "fisica";
      }
    
     $this->load->view('graduacaoGenerico',$conteudo);	
   }


	public function testandojs(){ 
		$arquivoOriginal = $_FILES['arquivo']['name']; 
		echo $arquivoOriginal;
		echo "ṕode pa";
	}


}
