<?php   defined('BASEPATH') OR exit('No direct script access allowed');

class Adm extends CI_Controller {
    function __construct() {
        parent::__construct();
        $this->load->helper('file');
        $this->load->helper('download');
        $this->load->helper('form');
        $this->load->helper('url');
        $this->load->library('upload');     
    }

    public function index(){
        $this->load->model('Disciplinas','',TRUE); 
        //$conteudo['resultado'] = $this->Disciplinas->arquivosDisciplina();
        $conteudo['resultado'] = $this->Disciplinas->arquivosDisciplinaTemporario();
        $conteudo['disciplinas'] = $this->Disciplinas->listarDisciplinas();
        $this->load->view('adm',$conteudo);	
    }

 }
