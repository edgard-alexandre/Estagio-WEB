<!DOCTYPE html>
<html lang="pt-br">
    <head>
	   <meta charset="UTF-8">
	   <title>Física Antunes</title>
        <link href="http://localhost/FisicaAntunes02/assets/css/estilosHome.css" rel="stylesheet">
        <link href="http://localhost/FisicaAntunes02/assets/bootstrap/css/bootstrap.min.css" rel="stylesheet">
        <script src="http://localhost/FisicaAntunes02/assets/jquery-3.2.0.min.js"  type="text/javascript"></script>
        <script src="http://localhost/FisicaAntunes02/assets/bootstrap/js/bootstrap.min.js"  type="text/javascript"></script>
    </head>
    <body>
    <div id="<?php echo $logo ;?>">
    </div>
        <nav id="menunav">
            <ul id="menu" class="nav nav-tabs">
                <li>
                    <form action="http://localhost/FisicaAntunes02/home"><button id="menuu" type="submit" class="btn btn-default navbar-btn"><b>Home</b></button></form>
                 </li>
                                
                    <li>
                     <a class="dropdown-toggle" data-toggle="dropdown" href="#" role="button" aria-haspopup="true" aria-expanded="false">Graduação<span class="caret"></span></a>
                    <ul class="dropdown-menu">
                          <?php 
							foreach($disciplinas as $disciplina){
                        ?>
                        <li>
                           <?php echo anchor(base_url("home/disciplina/".$disciplina->nome),$disciplina->nome);
                           ?> 
                        </li>
                          <?php
                          }
                        ?>
                     </ul> 
                    </li>

                    <li>
                     <a class="dropdown-toggle" data-toggle="dropdown" href="#" role="button" aria-haspopup="true" aria-expanded="false">Turmas<span class="caret"></span></a>
                    <ul class="dropdown-menu">
                         <li><a href="#">Graduação</a></li>
                         <li><a href="#">Técnico</a></li>
                    </ul>
                    </li>

                    <li>
                        <form action="http://localhost/FisicaAntunes02/home/teste">
                        <button id="menuu" type="submit" class="btn btn-default navbar-btn"><b>Teste</b></button>
                        </form>     
                    </li>


                    <li>   
                        <button type="button" class="btn btn-default navbar-btn" id="menuu" data-toggle="modal" data-target="#exampleModal"><b>Contato</b></button> 
                    </li> 



                    <li>
                        <button type="button" class="btn btn-default navbar-btn" id="menuu" data-toggle="modal" data-target="#exampleModal02"><b>Login</b></button>
                    </li>
                
            </ul>  
        </nav>


        <div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel">
            <div class="modal-dialog" role="document">
                <div class="modal-content">
                    <div class="modal-body">
          
             Telefones(CEFET - Formação Geral): (35) 3690-4216  <br>
                                                (35) 3690-4214  <br>
                                                (35) 3690-4234  <br>
             Email: pedroantunes.pd@gmail.com <br>
                    antunes.pd@gmail.com
        
                    </div>
                </div>
            </div>
        </div>

        <div class="modal fade" id="exampleModal02" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel">
            <div class="modal-dialog" role="document">
                <div class="modal-content">
                    <div class="modal-header">
                        <h4 class="modal-title" id="exampleModalLabel02">Para permissões administrativas,insira sua senha:</h4>
                    </div>
                    <div class="modal-body">
                        <div class="form-group">
                            <?php
                                $infoss = array('class' => 'form-label');
          		                $info = array('class' => 'form-control');
          		                $infos = array('class' => 'btn btn-default dropdown-toggle','id' => 'botao');
	      		                   echo form_open(base_url("home/login")) .
          		                    form_label("Senha: " ,"txt_senha",$infoss).br() .
                                       form_input("txt_camposenha",'',$info) . br().
                                       form_submit('nomequalquer','Enviar Mensagem',$infos).
                                       form_close();
                            ?>
                        </div>
                    </div>  
                </div>
            </div>
        </div>


<table border="1">  
  <?php    
    foreach($resultado as $result){
    ?>
     <tr>
      <td>
  
   <?php  $adidas = array('name'=>'userfile','value'=>$result->nomeArquivo);
     echo form_open_multipart("home/download").
          form_submit($adidas).
          form_close();
     ?>
      </td>
      <td>
    
    <?php  
        $submitExcluir = array('name'=>'oculto','value'=>'Excluir');
      echo form_open_multipart('home/deletar').
           form_submit($submitExcluir).
           form_hidden('campo_excluir',$result->nomeArquivo).
           form_close();
     ?>
     </td>
     </tr>
   <?php 
    }
    ?>
 
   
</table>
    </body>
</html>

