<!DOCTYPE html>
<html lang="pt-br">
<head>
	<meta charset="UTF-8">
	<title>Física Antunes</title>
    <link href="http://localhost/FisicaAntunes02/assets/css/estilos.css" rel="stylesheet">
    <link href="http://localhost/FisicaAntunes02/assets/bootstrap/css/bootstrap.min.css" rel="stylesheet">
    <script src="http://localhost/FisicaAntunes02/assets/jquery-3.2.0.min.js"  type="text/javascript"></script>
    <script src="http://localhost/FisicaAntunes02/assets/bootstrap/js/bootstrap.min.js"  type="text/javascript"></script>
    
</head>
<body>
   	<div id="menu">
        <ul>
            <li>
               <form action="http://localhost/FisicaAntunes02/home"><button id="menuu" type="submit" class="btn btn-default navbar-btn"><b>Home</b></button></form>
            <li>
               <form action="http://localhost/FisicaAntunes02/home/graduacao"><button id="menuu" type="submit" class="btn btn-default navbar-btn"><b>Graduacao</b></button></form>
            </li>
            <li>
              <form action="http://localhost/FisicaAntunes02/home/teste"><button id="menuu" type="submit" class="btn btn-default navbar-btn"><b>Teste</b></button></form>     
            </li>
            <li>
              <!-- Large button group -->
              <div class="btn-group">
                    <button class="btn btn-default btn-lg dropdown-toggle" type="button" data-toggle="dropdown" >
                    Sobre <span class="caret"></span>
                    </button>
              <ul class="dropdown-menu">
                   <li><a href="http://localhost/FisicaAntunes02/home/teste">Teste<a></li>
                   <li><a href="http://localhost/FisicaAntunes02/home/graduacao">Graduacao<a></li>
              </ul>
              </div>
               
            </li>
            <li>   
               <button type="button" class="btn btn-default navbar-btn" id="menuu" data-toggle="modal" data-target="#exampleModal"><b>Contato</b></button> 
            </li> 
            <li>
               <button type="button" class="btn btn-default navbar-btn" id="menuu" data-toggle="modal" data-target="#exampleModal02"><b>Login</b></button>
            </li>
  </ul> 
 </div>
</div>

<div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-body">
          
             Telefones(CEFET - Formação Geral): (35) 3690-4216  <br>
                                                (35) 3690-4214  <br>
                                                (35) 3690-4234  <br>
             Email: pedroantunes.pd@gmail.com <br>
                    antunes.pd@gmail.com
        
      </div>
    </div>
  </div>
</div>


 <div class="modal fade" id="exampleModal02" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h4 class="modal-title" id="exampleModalLabel02">Para permissões administrativas,insira sua senha:</h4>
      </div>
      <div class="modal-body">
 
          <div class="form-group">
          <?php
                $infoss = array('class' => 'form-label');
          		$info = array('class' => 'form-control');
          		$infos = array('class' => 'btn btn-default dropdown-toggle','id' => 'botao');
	      		echo form_open(base_url("home/login")) .
          		     form_label("Senha: " ,"txt_senha",$infoss).br() .
					 form_input("txt_camposenha",'',$info) . br().
					 form_submit('nomequalquer','Enviar Mensagem',$infos).
					 form_close();
          ?>
          </div>
      </div>  
    </div>
  </div>
</div>

<div id="microestrutura">
</div>

<div id="infosPedro">
<img src="http://localhost/FisicaAntunes02/assets/images/fotoPedro.jpg">
<div id="conteudo">
   Professor do Quadro Efetivo no Centro Federal de Educação Tecnológica de Minas Gerais - CEFET/MG Varginha, Graduado em Física pela UNIFOR/MG, Mestre em Ciências - Materiais para Engenharia pela Universidade Federal de Itajubá - UNIFEI, atualmente é aluno de doutorado do Programa Petrobras de Formação de Recursos Humanos - PFRH no Instituto de Engenharia Mecânica da UNIFEI e Tesoureiro do UNIFEI Student Chapter da SPE - Society of Petroleum Engineers, atua em áreas relacionadas à Ensino de Física, Energia, Petróleo e Materiais para Engenharia. Dedica-se a estudar a influência dos processos de soldagem na microestrutura, nas propriedades mecânicas, de corrosão e de desgaste em materiais de engenharia voltados para a indústria de petróleo através do uso de técnicas experimentais.
</div>
</div>




<div id="compromissos" class="cor">
  <h4 class="comp">Compromissos</h4> <br>
   <?php 
        foreach($compromissos as $compromisso){
       ?>
         <div id="compromisso">
            <div class="estiloCom">
          <?php
           $txtareaConteudo = array('name'=>'conteudo','value'=>$compromisso->conteudo,'class'=>'textarea');
           $submitEnviar = array('value'=>'Salvar','id'=>'enviar');
           echo form_open_multipart('home/salvarComp').
                form_textarea($txtareaConteudo).
                form_submit($submitEnviar).
                form_close();
           
           $submitExcluir = array('name'=>'oculto','value'=>'Excluir');
           echo form_open_multipart('home/deletarComp').
           form_submit($submitExcluir).
           form_hidden('campo_excluir',$compromisso->id).
           form_close();
           ?>
         </div>
         </div>
        <?php
        }
        ?>           
               
</div>
<div id="tabi">
<h4 class="comp"> Notas de Aula </h4>
<table class="Tabela">  
  <?php    
    foreach($nomes as $nome){
    ?>
     <tr>
      <td>
  
   <?php  $adidas = array('name'=>'userfile','class' =>'arquivoUp','value'=>$nome->nomeArq);
     echo form_open_multipart("home/download").
          form_submit($adidas).
          form_close();
     ?>
      </td>
      <td>
    
    <?php  
        $submitExcluir = array('name'=>'oculto','class'=>'BotaoExcluir','value'=>'Excluir');
      echo form_open_multipart('home/deletar').
           form_submit($submitExcluir).
           form_hidden('campo_excluir',$nome->nomeArq).
           form_close();
     ?>
     </td>
     </tr>
   <?php 
    }
    ?>  
</table>
</div>
<!-->
<div id="upload">
 <?php
    $addUpload = array('name' => 'arquivo','value' => 'Arquibao','type'=>'file');
    $addSubmit = array('name' => 'submit','value' => 'Enviar');
    echo form_open_multipart("home/salvar").
         form_upload($addUpload). br().
         form_submit($addSubmit).br().
         form_close();
    ?>
</div>
<!-->


   
</body>
</html>
