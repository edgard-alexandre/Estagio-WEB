<?php   defined('BASEPATH') OR exit('No direct script access allowed');

class Evento extends CI_Controller {
    function __construct() {
        parent::__construct();
      /* $this->load->helper('file');   
       $this->load->helper('form');
       $this->load->helper('url');
       $this->load->library('upload'); 
       $this->load->helper('string'); 
 */    
    }

    public function index(){
        $this->load->model('Disciplinas','',TRUE);
        $this->load->model('Tecnicos','',TRUE); 
        $this->load->model('Eventos','',TRUE);  
        $conteudo['eventos'] = $this->Eventos->listarEventos();
        $conteudo['disciplinas'] = $this->Disciplinas->listarDisciplinas();
        $conteudo['tecnicos'] = $this->Tecnicos->listarTecnicos();
        $this->load->view('eventos',$conteudo);	
    }


	  public function cadastrarEvento(){    
            $this->load->model('Eventos','',TRUE); 
            $nomeEvento = $_FILES['arquivo']['name']; 
            $conteudoEvento = $this->input->post('conteudoEvento');  
            $procura = '..';
            $substituto = '__';
            $nomeEvento = str_replace($procura,$substituto,$nomeEvento);
            $this->Eventos->cadastrarEvento($nomeEvento,$conteudoEvento);
            $idEvento = $this->Eventos->obterIdEvento($nomeEvento);
    			$configuracao = array(
    		    'upload_path'   => './uploads/',
    		    'allowed_types' => 'jpg|png|gif|pdf|zip|rar|doc|xls|mp3',
    		    'max_size'      => '5000000',
             'max_width'     => '3000000',
             'max_height'    => '2000000',
             'remove_spaces' => 'TRUE',
    	      );     
            $path = './uploads/eventos/';
            $configuracao['upload_path'] = $path;
    	 $this->upload->initialize($configuracao);
    	 if($this->upload->do_upload('arquivo')){
         $velhoCaminho= '../FisicaAntunes02/uploads/eventos/'.$nomeEvento;
         $novoCaminho= '../FisicaAntunes02/uploads/eventos/'.$idEvento;
         rename($velhoCaminho,$novoCaminho);
         redirect('evento');
     	 }else{
       	  echo $this->upload->display_errors();
       	 }  
   }

     public function alterarEvento(){
       $this->load->model('Eventos','',TRUE); 
       $idEvento = $this->input->post('campo_idEvento'); 
       $conteudoEvento = $this->input->post('conteudoEvento'); 
       $this->Eventos->alterarEvento($idEvento,$conteudoEvento);
     }
     public function excluirEvento(){
       $this->load->model('Eventos','',TRUE); 
       $idEvento = $this->input->post('campo_idEvento'); 
       $this->Eventos->excluirEvento($idEvento);
     }

 }
