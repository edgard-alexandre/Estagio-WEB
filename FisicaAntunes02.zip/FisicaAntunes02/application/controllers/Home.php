<?php   defined('BASEPATH') OR exit('No direct script access allowed');

class Home extends CI_Controller {
    function __construct() {
        parent::__construct();
        $this->load->helper('file');
        $this->load->helper('download');
        $this->load->helper('form');
        $this->load->helper('url');
        $this->load->library('upload');     
    }




	public function index(){
        $this->load->model('Disciplinas','',TRUE); 
        $this->load->model('Tecnicos','',TRUE); 
        $conteudos['disciplinas'] = $this->Disciplinas->listarDisciplinas();
        $conteudos['tecnicos'] = $this->Tecnicos->listarTecnicos();
		  $this->load->view('home',$conteudos);	
	}	




    public function login(){
        $this->load->model('Login','',TRUE); 
        $usuario = $this->input->post('txt_camposenha');
        $this->Login->verificacao($usuario);  
    }






    public function graduacao(){
     //verifica se o usuario logou.Views usadas sao inexistentes
      if(!$this->session->userdata('logado')){
          $this->load->view('Y');
      }else{
         $this->load->model('Graduacao','',TRUE);
         $this->load->model('Upload','',TRUE);
         $hor['resultado'] = $this->Graduacao->consultarHorarios();
         $comp['nomes'] = $this->Upload->consultarNomes();
         $comp['compromissos'] = $this->Graduacao->consultarCompromissos();
         $this->load->view('graduacao',$comp);
      }
    }







    public function teste(){
        $this->load->model('Upload','',TRUE);
        $this->load->model('Disciplinas','',TRUE); 
        $conteudo['resultado'] = $this->Upload->consultarNomes();
        $conteudo['disciplinas'] = $this->Disciplinas->listarDisciplinas();
        $this->load->view('teste',$conteudo);	
    }

  public function verificaDisciplina(){
     $this->load->model('Upload','',TRUE); 
     $arquivoOriginal = $_FILES['arquivo']['name']; 
     $idDisciplina = $this->input->post('campo_idDisciplina');  
     $verifica = $this->Upload->verificaUpload($arquivoOriginal,$idDisciplina); 
     if($verifica){
       $id = $this->Upload->obterIdArquivo($arquivoOriginal,$idDisciplina);
       $arqExc = 'arquivoqueseraexcluido';
       $velhoCaminho= '../FisicaAntunes02/uploads/disciplinas/'.$idDisciplina.'/'.$arquivoOriginal;
       $novoCaminho= '../FisicaAntunes02/uploads/disciplinas/'.$idDisciplina.'/'.$arqExc;
       rename($velhoCaminho,$novoCaminho);
       $this->Upload->renomear($id,$arqExc);
       $this->Upload->deletarRenomeado($idDisciplina,$arqExc);
       $this->salvar($arquivoOriginal,$idDisciplina);
      }else{
         $this->salvar($arquivoOriginal,$idDisciplina); 
     }
     
  }

	public function salvar($arquivo,$idDisciplina){    
            $this->load->model('Upload','',TRUE); 
           /* $arq1 = $arquivo;
            $arq2 = $arquivo;
            $disc1 = $disciplinaNome;
            $disc2 = $disciplinaNome;*/
    			$configuracao = array(
    		    'upload_path'   => './uploads/',
    		    'allowed_types' => 'jpg|png|gif|pdf|zip|rar|doc|xls|mp3',
    		    'max_size'      => '5000000',
             'max_width'     => '3000',
             'max_height'    => '2000',
             'remove_spaces' => 'TRUE',
    	      );     
            $path = './uploads/disciplinas/'.$idDisciplina.'/';
            $configuracao['upload_path'] = $path;
    	 $this->upload->initialize($configuracao);
    	 if($this->upload->do_upload('arquivo')){
         $procura = '..';
         $substituto = '__';
         $arquivo = str_replace($procura,$substituto,$arquivo);
          $this->Upload->nomeUpload($arquivo,$idDisciplina);
           echo 'Arquivo salvo com sucesso';
        	  redirect('home/teste');
     	 }else{
       	  echo $this->upload->display_errors();
       	 }  
   }


   public function renomearDisciplina(){
       $this->load->model('Disciplinas','',TRUE);  
       $novoNome = $this->input->post('novoNome');
       $idDisciplina = $this->input->post('campo_idDisciplina');
       $this->Disciplinas->renomearDisciplina($novoNome,$idDisciplina); 
       
   }


   public function download(){
     $nomeArquivo = $this->input->post('campo_nomeArquivo');
     $idDisciplina = $this->input->post('campo_idDisciplina');
     $arquivoPath = './uploads/disciplinas/'.$idDisciplina.'/'.$nomeArquivo;
    // forçamos o download no browser 
     // passando como parâmetro o path original do arquivo
     force_download($arquivoPath,null);    
   }


   public function deletarDisciplina(){
     $this->load->model('Disciplinas','',TRUE); 
     $idDisciplina = $this->input->post('campo_idDisciplina');
     $this->Disciplinas->deletarDisciplina($idDisciplina);
     
   }


  public function deletarArquivoDisciplina(){
    $this->load->model('Upload','',TRUE);
    $nomeArquivo = $this->input->post('campo_nomeArquivo');
    $idDisciplina = $this->input->post('campo_idDisciplina');
    $this->Upload->deletarArquivoDisciplina($nomeArquivo,$idDisciplina); 
  }

  


  public function cadastroDisciplina(){
    $this->load->model('Disciplinas','',TRUE);
    $nome = $this->input->post('nomeDisciplina');
    $nomeDisciplina = $nome;
    $this->Disciplinas->cadastrarDisciplina($nomeDisciplina);
    $idDisciplina = $this->Disciplinas->obterIdDisciplina($nomeDisciplina);
    mkdir('../FisicaAntunes02/uploads/disciplinas/'.$idDisciplina, 0777);
    redirect('home/teste');
  }


  public function disciplina($nomeDisciplina){
     $nomeDisciplina = urldecode($nomeDisciplina);
     $this->load->model('Disciplinas','',TRUE); 
     $this->load->model('Upload','',TRUE);
     $conteudo['resultado'] = $this->Upload->consultarNomes();
     $conteudo['disciplinas'] = $this->Disciplinas->listarDisciplinas();
     $conteudo['logo'] = mb_substr($nomeDisciplina,0,3);
     $conteudo['logo'] = strtolower($conteudo['logo']);
 
	 if ($conteudo['logo'] == "lab"){
         $conteudo['logo'] = "laboratorio";
      } else {
         $conteudo['logo'] = "fisica";
      }
    
     $this->load->view('graduacaoGenerico',$conteudo);	
   }




}
