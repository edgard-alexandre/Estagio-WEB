<html lang="pt-br">
<head>
	<meta charset="UTF-8">
	<title>Física Antunes</title>
    <link href="http://localhost/FisicaAntunes02/assets/css/estilos.css" rel="stylesheet">
    <link href="http://localhost/FisicaAntunes02/assets/bootstrap/css/bootstrap.min.css" rel="stylesheet">
    <script src="http://localhost/FisicaAntunes02/assets/jquery-3.2.0.min.js"  type="text/javascript"></script>
    <script src="http://localhost/FisicaAntunes02/assets/bootstrap/js/bootstrap.min.js"  type="text/javascript"></script>
    
</head>
<body>
   
        <ul>
            <li>
               <?php 
                    echo anchor(base_url("home"),"HOME");
                ?> 
            </li>
            <li>
               <?php 
                    echo anchor(base_url("home/graduacao"),"GRADUACAO");
                ?> </li>
            <li>
               <?php 
                    $teste = array('color' => 'red');
                    echo anchor(base_url("home/teste"),"Testhbvhj",$teste);
                ?>
            </li>
            <li>SOBRE</li>
            <li>CONTATO</li>
            <li>
               <button type="button" class="btn btn-primary" data-toggle="modal" data-target="#exampleModal">Login</button>
 
            </li>
  </ul> 
 <div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
        <h4 class="modal-title" id="exampleModalLabel">Para permissões administrativas , insira sua senha: </h4>
      </div>
      <div class="modal-body">
 
          <div class="form-group">
          <?php
                $infoss = array('class' => 'form-label');
          		$info = array('class' => 'form-control');
          		$infos = array('class' => 'btn btn-default dropdown-toggle','id' => 'botao');
	      		echo form_open(base_url("home/login")) .
          		     form_label("Senha: " ,"txt_senha",$infoss).br() .
					 form_input("txt_camposenha",'',$info) . br().
					 form_submit('nomequalquer','Enviar Mensagem',$infos).
					 form_close();
          ?>
          </div>
      </div>
      
    </div>
  </div>
</div>
    
