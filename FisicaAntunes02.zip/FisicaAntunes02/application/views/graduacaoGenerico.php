<!DOCTYPE html>
<html lang="pt-br">
    <head>
	   <meta charset="UTF-8">
	   <title>Física Antunes</title>
        <link href="http://localhost/FisicaAntunes02/assets/bootstrap/css/bootstrap.min.css" rel="stylesheet">
        <script src="http://localhost/FisicaAntunes02/assets/jquery-3.2.0.min.js"  type="text/javascript"></script>
        <script src="http://localhost/FisicaAntunes02/assets/bootstrap/js/bootstrap.min.js"  type="text/javascript"></script>
		<link href="http://localhost/FisicaAntunes02/assets/css/estilosArquivos.css" rel="stylesheet">
    </head>
    <body>
	<div id="content">
    	<div id="<?php echo $logo;?>" class="eletronfoto">
		</div> 
    	<div id="Meenu">
        	<nav id="menunav">
        	    <ul id="menu" class="nav nav-tabs">
        	        <li>
        	            <form action="http://localhost/FisicaAntunes02/home"><button id="menuu" type="submit" class="btn btn-default navbar-btn"><b>Home</b></button></form>
        	         </li>                        
                    	<li>
                     		<a class="dropdown-toggle" data-toggle="dropdown" href="#" role="button" aria-haspopup="true" aria-expanded="false" id="menuu">Graduação<span class="caret"></span></a>
                    		<ul id="menuuu" class="dropdown-menu">
                          		<?php 
									foreach($disciplinas as $disciplina){
                        				?>
                        				<li>
                          	 				<?php 
												echo anchor(base_url("disciplina/disciplina/".$disciplina->nome),'<span id="drop">' . $disciplina->nome . '</span>');
                          	 				?>
                        				</li>
                          				<?php
                          					}
                        				?>
                     		</ul> 
                    	</li>
                    	<li>
                     		<a class="dropdown-toggle" data-toggle="dropdown" href="#" role="button" aria-haspopup="true" aria-expanded="false" id="menuu">Técnicos<span class="caret"></span></a>
                     		<ul id="menuuu" class="dropdown-menu">
                          		<?php 
									foreach($tecnicos as $tecnico){
                        	  ?>
                  			   <li>
                           	 <?php echo anchor(base_url("tecnico/tecnico/".$tecnico->nomeTecnico),'<span id="drop">' . $tecnico->nomeTecnico. '</span>');
                           	 ?> 
                          		</li>
                       
                         				<?php
                          					}
                        				?>
                     		</ul> 
                    	</li>
                     <li>
                        <form action="http://localhost/FisicaAntunes02/evento"><button id="menuu" type="submit" class="btn btn-default navbar-btn"><b>Eventos</b></button></form>
                     </li>
                    	<li>
                          <button type="button" class="btn btn-default navbar-btn" id="menuu" data-toggle="modal" data-target="#loginADM">ADM</button>
                    	</li>
                    	<li>   
                        	<button type="button" class="btn btn-default navbar-btn" id="menuu" data-toggle="modal" data-target="#exampleModal"><b>Contato</b></button> 
                    	</li>   
            	</ul>  
        	</nav>
			<div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel">
	            <div class="modal-dialog" role="document">
	                <div class="modal-content">
	                    <div class="modal-body">
          
             Telefones (CEFET - Formação Geral): (35) 3690-4216  <br>
                                                (35) 3690-4214  <br>
                                                (35) 3690-4234  <br>
             Email: pedroantunes.pd@gmail.com <br>
                    antunes.pd@gmail.com
        
	                    </div>
	                </div>
	            </div>
	        </div>
        	<div class="modal fade" id="loginADM" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel">
            	<div class="modal-dialog" role="document">
            	    <div class="modal-content">
            	        <div class="modal-header">
            	            <h4 class="modal-title" id="exampleModalLabel02">Para permissões administrativas, insira sua senha:</h4>
            	        </div>
            	        <div class="modal-body">
           		            <div class="form-group">
           		                <?php
                                $infoss = array('class' => 'form-label');
          		                $info = array('class' => 'form-control');
          		                $infos = array('class' => 'btn btn-default dropdown-toggle','id' => 'botao');
	      		                   echo form_open(base_url("adm/login")) .
          		                    form_label("Senha: " ,"txt_senha",$infoss).br() .
                                       form_input("txt_camposenha",'',$info) . br().
                                       form_submit('nomequalquer','Enviar Mensagem',$infos).
                                       form_close();
            	                ?>
            	            </div>
            	        </div>  
            	    </div>
            	</div>
        	</div>
<!--////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////-->

 <table border="1">  
  <?php    
    foreach($arquivosDisciplina as $arquivoDisciplina){
    ?>
     <tr>
      <td>
  
   <?php  
       $submitDownload = array('name'=>'nomeArquivo','value'=>$arquivoDisciplina->nomeArquivo,'class'=>'btn btn-default navbar-btn');
          echo form_open_multipart("disciplina/download").
          form_submit($submitDownload). 
          form_hidden('campo_nomeArquivo',$arquivoDisciplina->nomeArquivo).
          form_hidden('campo_idDisciplina',$arquivoDisciplina->idDisciplina).
          form_close();
    
     				?>
      </td>
     </tr>
   <?php 
    }
    ?>
 
   
</table>

   
			
			<footer>
				<div id="rodape">
				</div>
			</footer>
		</div>
    </body>
</html>






<!--

<table border="1">  
  <?php    
    foreach($resultado as $result){
    ?>
     <tr>
      <td>
  
   <?php  $adidas = array('name'=>'userfile','value'=>$result->nomeArquivo);
     echo form_open_multipart("home/download").
          form_submit($adidas).
          form_close();
     ?>
      </td>
     </tr>
   <?php 
    }
    ?>
 
   
</table>
-->
