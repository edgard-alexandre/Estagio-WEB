<!DOCTYPE html>
<html lang="pt-br">
<head>
	<meta charset="UTF-8">
	<title>Física Antunes</title>
    <link href="http://localhost/FisicaAntunes02/assets/css/estilos.css" rel="stylesheet">
    <link href="http://localhost/FisicaAntunes02/assets/bootstrap/css/bootstrap.min.css" rel="stylesheet">
    <script src="http://localhost/FisicaAntunes02/assets/jquery-3.2.0.min.js"  type="text/javascript"></script>
    <script src="http://localhost/FisicaAntunes02/assets/bootstrap/js/bootstrap.min.js"  type="text/javascript"></script>
    
</head>
<body> 

<table border="1">  
  <?php    
    foreach($resultado as $result){
    ?>
     <tr>
      <td>
  
   <?php  
          $submitDownload = array('name'=>'nomeArquivo','value'=>$result->nomeArquivo,'class'=>'btn btn-default navbar-btn');
     echo form_open_multipart("disciplina/download").
          form_submit($submitDownload).
          form_hidden('campo_nomeArquivo',$result->nomeArquivo).
          form_hidden('campo_idDisciplina',$result->idDisciplina).
          form_close();
     ?>
      </td>
      <td>
    
    <?php  
        $submitExcluir = array('name'=>'oculto','value'=>'Excluir','class'=>'btn btn-default navbar-btn');
      echo form_open_multipart('disciplina/deletarArquivoDisciplina').
           form_submit($submitExcluir).
           form_hidden('campo_nomeArquivo',$result->nomeArquivo).
           form_hidden('campo_idDisciplina',$result->idDisciplina).
           form_close();
     ?>
     </td>
     </tr>
   <?php 
    }
    ?> 
</table>
                <table>
                        <?php
                          foreach($disciplinas as $disciplina){
                        ?>
                        <tr>
                         <td>
                           <?php
                              
                              $submitRenomear = array('name'=>$disciplina->idDisciplina,'value'=>'Renomear');
                               $info = array('class' => 'form-control');
	      		                   echo form_open('disciplina/renomearDisciplina').
                                       form_input("novoNome",$disciplina->nome,$info).
                                       form_hidden('campo_idDisciplina',$disciplina->idDisciplina).
                                       form_submit($submitRenomear).
                                       form_close();
                                  
                           ?> 
                         </td>
                         <td>
                            <?php  
                         		$submitExcluir = array('name'=>'oculto','value'=>'Excluir','class'=>'btn btn-default navbar-btn');
     							 		echo form_open_multipart('disciplina/deletarDisciplina').
          					 		form_submit($submitExcluir).
          					 		form_hidden('campo_idDisciplina',$disciplina->idDisciplina).
          					 		form_close();
    								 ?>   
                         </td>
                          <td>
                            <?php
                              $addUpload = array('name' => 'arquivo','value' => 'Arquibao',
                                         'type'=>'file','class'=>'btn btn-default navbar-btn');     
    									$addSubmit = array('name' => 'submit','value' => 'Enviar','class'=>'btn btn-default navbar-btn');    
    									echo form_open_multipart("disciplina/verificaDisciplina").
         							form_upload($addUpload).
                              form_hidden('campo_idDisciplina',$disciplina->idDisciplina).
                              form_submit($addSubmit). 
         							form_close();
    								 ?>
                         </td>
                         </tr>
                          <?php
                          }
                        ?>
                   
              
	<button type="button" class="btn btn-default navbar-btn" id="menuu" data-toggle="modal" data-target="#exampleModal02"><b>Cadastrar</b></button>
  		<div class="modal fade" id="exampleModal02" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel">
            	<div class="modal-dialog" role="document">
                	<div class="modal-content">
                    	<div class="modal-header">
                        	<h4 class="modal-title" id="exampleModalLabel02">Nova disciplina:</h4>
                    	</div>
                    	<div class="modal-body">
                        	<div class="form-group">
                            	<?php
                                
          		                	$info = array('class' => 'form-control');
          		                	$infos = array('class' => 'btn btn-default dropdown-toggle','id' => 'botao');
	      		                   		echo form_open(base_url("disciplina/cadastroDisciplina")) .
                                       		form_input("nomeDisciplina",'',$info) . br().
                                       		form_submit('nomequalquer','Cadastrar',$infos).
                                       		form_close();
                            	?>
                        	</div>
                    	</div>  
                	</div>
            	</div>
        	</div>
		</table>        
	</body>
</html>
