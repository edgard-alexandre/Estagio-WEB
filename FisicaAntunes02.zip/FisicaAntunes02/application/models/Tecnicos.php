<?php defined('BASEPATH') OR exit('No direct script access allowed');
class Tecnicos extends CI_Model {
        function __construct() {
           parent::__construct();
          
        }

        public function listarTecnicos(){
            return $this->db->get('tecnicos')->result();
           
         }
        
}
